package com.mycompany.posttest1.service;

import com.mycompany.posttest1.db.DbViewer;
import com.mycompany.posttest1.model.BarangEntity;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Service {
    private final Scanner in;

    private static final EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("lelangPU");

    public Service(Scanner in) {
        this.in = in;
    }

    private EntityManager em() {
        return emf.createEntityManager();
    }

    // ----------------- JDBC (Statement) -----------------
    public void tampilkanDenganJDBC() {
        System.out.println("\n==                                                DAFTAR KOLEKSI AntikAesthetic                                            ==");
        DbViewer.showBarang();
    }

    // ----------------- READ (ORM) -----------------
    public void tampilkanSemua() {
        EntityManager em = em();
        try {
            TypedQuery<BarangEntity> q = em.createQuery(
                    "SELECT b FROM BarangEntity b ORDER BY b.id", BarangEntity.class);
            tampilkanTabelBarang(q.getResultList(), true);
        } finally { em.close(); }
    }

    // ----------------- CREATE (ORM) -----------------
    public void tambahBarang() {
        System.out.println("\n.......................................................");
        System.out.println("             TAMBAH BARANG AntikAesthetic             ");
        System.out.println(".......................................................");

        String nama     = inputString("Nama");
        String kategori = inputString("Kategori");
        String asal     = inputString("Asal");
        int tahun       = inputInt("Tahun", 0, 3000);
        String material = inputString("Material");
        String kondisi  = inputString("Kondisi");
        String sumber   = inputString("Sumber (Lelang/Warisan/Hibah/dll)");
        double harga    = inputDouble("Harga Perolehan", 0, Double.MAX_VALUE);

        BarangEntity e = new BarangEntity();
        e.setNama(nama);
        e.setKategori(kategori);
        e.setAsal(asal);
        e.setTahun(tahun);
        e.setMaterial(material);
        e.setKondisi(kondisi);
        e.setSumber(sumber);
        e.setHargaPerolehan(harga);
        e.setTipe(tipeDariSumber(sumber));

        EntityManager em = em();
        try {
            em.getTransaction().begin();
            em.persist(e);
            em.getTransaction().commit();
        } finally { em.close(); }

        System.out.println(">> Barang berhasil ditambahkan dengan ID: " + e.getId());
    }

    // ----------------- UPDATE (ORM) -----------------
    public void perbaruiBarang() {
        System.out.println("...........................................................................................................................");
        System.out.println("                                               PERBARUI BARANG AntikAesthetic                                              ");
        System.out.println("-------------------------------------------------- Cari Berdasarkan ID ----------------------------------------------------");
        System.out.println("...........................................................................................................................");
        tampilkanSemuaTanpaFooter();

        System.out.print("\nMasukkan ID yang diperbarui: ");
        int id = parseIntSafe(in.nextLine());

        BarangEntity e = findById(id);
        if (e == null) { System.out.println("ID tidak ditemukan."); return; }

        System.out.println("Kosongkan input untuk melewati (tidak mengubah).");
        System.out.println("=================================================");
        e.setNama(            inputStringOpsional("Nama baru", e.getNama()));
        e.setKategori(        inputStringOpsional("Kategori baru", e.getKategori()));
        e.setAsal(            inputStringOpsional("Asal baru", e.getAsal()));
        e.setTahun(           inputIntOpsional("Tahun baru", e.getTahun(), 0, 3000));
        e.setMaterial(        inputStringOpsional("Material baru", e.getMaterial()));
        e.setKondisi(         inputStringOpsional("Kondisi baru", e.getKondisi()));
        String sumberBaru =   inputStringOpsional("Sumber baru", e.getSumber());
        e.setSumber(sumberBaru);
        e.setTipe(tipeDariSumber(sumberBaru));
        e.setHargaPerolehan(  inputDoubleOpsional("Harga Perolehan baru", e.getHargaPerolehan(), 0, Double.MAX_VALUE));

        EntityManager em = em();
        try {
            em.getTransaction().begin();
            em.merge(e);                      // simpan perubahan
            em.getTransaction().commit();
        } finally { em.close(); }

        System.out.println("........ Data berhasil diperbarui ........");
    }

    // ----------------- DELETE (ORM) -----------------
    public void hapusBarang() {
        System.out.println();
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        System.out.println("                                               HAPUS BARANG AntikAesthetic                                              ");
        System.out.println("-------------------------------------------------- Cari Berdasarkan ID ----------------------------------------------------");
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

        tampilkanSemuaTanpaFooter();

        Integer id = null;
        while (true) {
            System.out.print("Masukkan ID yang akan dihapus : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) { System.out.println("Input tidak boleh kosong."); continue; }
            try { id = Integer.valueOf(s); } catch (NumberFormatException ex) { System.out.println("Oops... Harus berupa angka."); continue; }
            if (findById(id) == null) { System.out.println("Data dengan ID " + id + " tidak ditemukan."); continue; }
            break;
        }

        System.out.print("Yakin hapus ID " + id + " (y/n)? ");
        String ans = in.nextLine().trim().toLowerCase(Locale.ROOT);
        if (!ans.equals("y")) { System.out.println(">>>>> Dibatalkan <<<<<"); return; }

        EntityManager em = em();
        try {
            em.getTransaction().begin();
            BarangEntity found = em.find(BarangEntity.class, id);
            if (found != null) em.remove(found);
            em.getTransaction().commit();
        } finally { em.close(); }

        System.out.println("~~~~~~~ Data ID " + id + " telah dihapus ~~~~~~~");
    }

    // ----------------- SEARCH (ORM) -----------------
    public void cariBarang() {
        System.out.println("\n========================================================");
        System.out.println("                 CARI BARANG AntikAesthetic             ");
        System.out.println("========================================================");

        String key = inputString("Kata kunci").toLowerCase(Locale.ROOT);

        EntityManager em = em();
        try {
            TypedQuery<BarangEntity> q = em.createQuery(
                    "SELECT b FROM BarangEntity b " +
                    "WHERE lower(b.nama) LIKE :k OR lower(b.kategori) LIKE :k OR lower(b.asal) LIKE :k " +
                    "ORDER BY b.id", BarangEntity.class);
            q.setParameter("k", "%" + key + "%");
            List<BarangEntity> hasil = q.getResultList();

            if (hasil.isEmpty()) { System.out.println("Oops.. Tidak ada hasil untuk: " + key); return; }

            tampilkanTabelBarang(hasil, false);

            System.out.println("\n********* RINGKASAN *********");
            for (BarangEntity b : hasil) {
                System.out.println("- #" + b.getId() + " " + b.getNama() + " (" + b.getKategori() + ") | asal: " + b.getAsal()
                        + " | sumber: " + b.getSumber() + " [" + b.getTipe() + "]");
            }
        } finally { em.close(); }
    }

    // ----------------- Helper ORM -----------------
    private BarangEntity findById(int id) {
        EntityManager em = em();
        try { return em.find(BarangEntity.class, id); }
        finally { em.close(); }
    }

    private List<BarangEntity> listAll() {
        EntityManager em = em();
        try {
            return em.createQuery("SELECT b FROM BarangEntity b ORDER BY b.id", BarangEntity.class)
                     .getResultList();
        } finally { em.close(); }
    }

    private void tampilkanSemuaTanpaFooter() {
        tampilkanTabelBarang(listAll(), false);
    }

    // ----------------- Table Renderer -----------------
    private void tampilkanTabelBarang(List<BarangEntity> list, boolean showFooter) {
        System.out.println("\n+----+----------------------+--------------+--------------+-------+--------------+-----------+-----------+------------------+");
        System.out.println("| ID | Nama                 | Kategori     | Asal         | Tahun | Material     | Kondisi   | Sumber    | Harga            |");
        System.out.println("+----+----------------------+--------------+--------------+-------+--------------+-----------+-----------+------------------+");
        if (list == null || list.isEmpty()) {
            System.out.printf("| %-110s |\n", "Belum ada data barang");
        } else {
            for (BarangEntity b : list) {
                System.out.printf("| %-2d | %-20s | %-12s | %-12s | %-5d | %-12s | %-9s | %-9s | Rp. %-12.0f |\n",
                        b.getId(),
                        potong(b.getNama(), 20),
                        potong(b.getKategori(), 12),
                        potong(b.getAsal(), 12),
                        b.getTahun(),
                        potong(b.getMaterial(), 12),
                        potong(b.getKondisi(), 9),
                        potong(b.getSumber(), 9),
                        b.getHargaPerolehan()
                );
            }
        }
        System.out.println("+----+----------------------+--------------+--------------+-------+--------------+-----------+-----------+------------------+");
        if (showFooter) System.out.println("~~~ Tekan Enter untuk melanjutkan..");
    }

    // ----------------- Utils I/O -----------------
    public void enterUntukLanjut() {
        System.out.print("\nTekan ENTER untuk lanjut...");
        in.nextLine();
    }

    private static String tipeDariSumber(String sumber) {
        if (sumber == null) return "UMUM";
        if (sumber.equalsIgnoreCase("Lelang")) return "LELANG";
        if (sumber.equalsIgnoreCase("Warisan")) return "WARISAN";
        return "UMUM";
    }

    private String potong(String s, int maxLen) {
        if (s == null) return "";
        if (s.length() <= maxLen) return s;
        if (maxLen <= 1) return s.substring(0, 1);
        return s.substring(0, maxLen - 1) + "…";
    }

    private int parseIntSafe(String s) {
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return 0; }
    }

    private String inputString(String label) {
        while (true) {
            System.out.print(label + " : ");
            String s = in.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Input tidak boleh kosong.");
        }
    }

    private int inputInt(String label, int min, int max) {
        while (true) {
            System.out.print(label + " : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) { System.out.println("Input tidak boleh kosong."); continue; }
            try {
                int val = Integer.parseInt(s);
                if (val < min || val > max) System.out.println("Harus di antara " + min + " dan " + max + ".");
                else return val;
            } catch (NumberFormatException e) { System.out.println("Harus berupa angka."); }
        }
    }

    private double inputDouble(String label, double min, double max) {
        while (true) {
            System.out.print(label + " : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) { System.out.println("Input tidak boleh kosong."); continue; }
            try {
                double val = Double.parseDouble(s.replace("_", ""));
                if (val < min || val > max) System.out.println("Harus di antara " + min + " dan " + (max == Double.MAX_VALUE ? "tak hingga" : max) + ".");
                else return val;
            } catch (NumberFormatException e) { System.out.println("Harus berupa angka (boleh desimal)."); }
        }
    }

    private String inputStringOpsional(String label, String lama) {
        System.out.print(label + " [" + lama + "] : ");
        String s = in.nextLine().trim();
        return s.isEmpty() ? lama : s;
    }

    private int inputIntOpsional(String label, int lama, int min, int max) {
        while (true) {
            System.out.print(label + " [" + lama + "] : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) return lama;
            try {
                int val = Integer.parseInt(s);
                if (val < min || val > max) System.out.println("Harus di antara " + min + " dan " + max + ".");
                else return val;
            } catch (NumberFormatException e) { System.out.println("Harus berupa angka."); }
        }
    }

    private double inputDoubleOpsional(String label, double lama, double min, double max) {
        while (true) {
            System.out.print(label + " [Rp" + String.format("%,.0f", lama) + "] : ");
            String s = in.nextLine().trim();
            if (s.isEmpty()) return lama;
            try {
                double val = Double.parseDouble(s.replace("_", ""));
                if (val < min || val > max) System.out.println("Harus di antara " + min + " dan " + (max == Double.MAX_VALUE ? "tak hingga" : max) + ".");
                else return val;
            } catch (NumberFormatException e) { System.out.println("Harus berupa angka (boleh desimal)."); }
        }
    }
}
