package com.mycompany.posttest1.model;

import jakarta.persistence.*;

@Entity
@Table(name = "barang")
public class BarangEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    @Column(name = "id")
    private Integer id;

    @Column(name="tipe", nullable=false)   private String tipe;
    @Column(name="nama", nullable=false)   private String nama;
    @Column(name="kategori")               private String kategori;
    @Column(name="asal")                   private String asal;
    @Column(name="tahun")                  private Integer tahun;
    @Column(name="material")               private String material;
    @Column(name="kondisi")                private String kondisi;
    @Column(name="sumber")                 private String sumber;
    @Column(name="hargaPerolehan")         private Double hargaPerolehan;

    public BarangEntity() {} 

    public BarangEntity(int id, String tipe, String nama, String kategori,
                        int tahun, String material, String kondisi,
                        String sumber, double hargaPerolehan) {
        this.id = id;
        this.tipe = tipe;
        this.nama = nama;
        this.kategori = kategori;
        this.tahun = tahun;
        this.material = material;
        this.kondisi = kondisi;
        this.sumber = sumber;
        this.hargaPerolehan = hargaPerolehan;
    }

    // getter-setter
    public Integer getId() { return id; }                   public void setId(Integer id) { this.id = id; }
    public String getTipe() { return tipe; }                public void setTipe(String tipe) { this.tipe = tipe; }
    public String getNama() { return nama; }                public void setNama(String nama) { this.nama = nama; }
    public String getKategori() { return kategori; }        public void setKategori(String kategori) { this.kategori = kategori; }
    public String getAsal() { return asal; }                public void setAsal(String asal) { this.asal = asal; }
    public Integer getTahun() { return tahun; }             public void setTahun(Integer tahun) { this.tahun = tahun; }
    public String getMaterial() { return material; }        public void setMaterial(String material) { this.material = material; }
    public String getKondisi() { return kondisi; }          public void setKondisi(String kondisi) { this.kondisi = kondisi; }
    public String getSumber() { return sumber; }            public void setSumber(String sumber) { this.sumber = sumber; }
    public Double getHargaPerolehan() { return hargaPerolehan; }
    public void setHargaPerolehan(Double hargaPerolehan) { this.hargaPerolehan = hargaPerolehan; }
}

