package com.mycompany.posttest1.model;

public class barangLelang extends Barang {
    public barangLelang(int id, String nama, String kategori, String asal, int tahun,
                        String material, String kondisi, String sumber, double hargaPerolehan) {
        super(id, "LELANG", nama, kategori, asal, tahun, material, kondisi, sumber, hargaPerolehan);
    }

    @Override
    public double hitungAsuransi() {
        return estimasiNilai(1.1) * 0.015;   // premi 1.5% dengan faktor 1.1
    }

    @Override
    public String getTipe() { return "LELANG"; }

    @Override
    public double estimasiNilai(double faktorKondisi) {
        return Math.max(0, super.estimasiNilai(faktorKondisi) * 1.05);
    }

    @Override
    public String infoSingkat() {
        return super.infoSingkat() + " | tipe: LELANG";
    }
}
