package com.mycompany.posttest1.model;

public class Barang {
    private Integer id;
    private String  tipe;            // "UMUM" | "LELANG" | "WARISAN"
    private String  nama;
    private String  kategori;
    private String  asal;
    private Integer tahun;
    private String  material;
    private String  kondisi;
    private String  sumber;
    private Double  hargaPerolehan;

    public Barang() {}

    public Barang(Integer id, String tipe, String nama, String kategori,
                  String asal, Integer tahun, String material,
                  String kondisi, String sumber, Double hargaPerolehan) {
        this.id = id;
        this.tipe = tipe;
        this.nama = nama;
        this.kategori = kategori;
        this.asal = asal;
        this.tahun = tahun;
        this.material = material;
        this.kondisi = kondisi;
        this.sumber = sumber;
        this.hargaPerolehan = hargaPerolehan;
    }

    // ---- getter-setter
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getTipe() { return tipe; }
    public void setTipe(String tipe) { this.tipe = tipe; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public String getAsal() { return asal; }
    public void setAsal(String asal) { this.asal = asal; }

    public Integer getTahun() { return tahun; }
    public void setTahun(Integer tahun) { this.tahun = tahun; }

    public String getMaterial() { return material; }
    public void setMaterial(String material) { this.material = material; }

    public String getKondisi() { return kondisi; }
    public void setKondisi(String kondisi) { this.kondisi = kondisi; }

    public String getSumber() { return sumber; }
    public void setSumber(String sumber) { this.sumber = sumber; }

    public Double getHargaPerolehan() { return hargaPerolehan; }
    public void setHargaPerolehan(Double hargaPerolehan) { this.hargaPerolehan = hargaPerolehan; }

    // ---- method dasar yang bisa dioverride turunan
    public double estimasiNilai(double faktorKondisi) {
        double h = (hargaPerolehan == null) ? 0.0 : hargaPerolehan;
        return Math.max(0, h * faktorKondisi);
    }

    public double hitungAsuransi() {        // default, boleh dioverride
        return estimasiNilai(1.0) * 0.010;
    }

    public String infoSingkat() {
        return (id == null ? "" : id) + " | " +
               (nama == null ? "" : nama) + " | " +
               (kategori == null ? "" : kategori);
    }
}
