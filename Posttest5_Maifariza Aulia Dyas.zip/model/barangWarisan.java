package com.mycompany.posttest1.model;

public class barangWarisan extends Barang {
    public barangWarisan(int id, String nama, String kategori, String asal, int tahun,
                         String material, String kondisi, String sumber, double hargaPerolehan) {
        super(id, "WARISAN", nama, kategori, asal, tahun, material, kondisi, sumber, hargaPerolehan);
    }

    @Override
    public double hitungAsuransi() {
        return estimasiNilai(1.0) * 0.008;   // premi 0.8%
    }

    @Override
    public String getTipe() { return "WARISAN"; }

    @Override
    public String infoSingkat() {
        return super.infoSingkat() + " | tipe: WARISAN";
    }
}
