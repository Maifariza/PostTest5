package com.mycompany.posttest1.model;

public class barangUmum extends Barang {
    public barangUmum(int id, String nama, String kategori, String asal, int tahun,
                      String material, String kondisi, String sumber, double hargaPerolehan) {
        super(id, "UMUM", nama, kategori, asal, tahun, material, kondisi, sumber, hargaPerolehan);
    }

    @Override
    public double hitungAsuransi() {
        return estimasiNilai(1.0) * 0.010;   
    }

    @Override
    public String getTipe() { return "UMUM"; }

    @Override
    public String infoSingkat() {
        return super.infoSingkat() + " | tipe: UMUM";
    }
}

