package com.mycompany.posttest1.model;

/** Interface penilaian (Abstraction via interface). */
public interface Penilaian {
    double estimasiNilai(double faktorKondisi);
}