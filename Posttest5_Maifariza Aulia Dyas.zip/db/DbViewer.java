package com.mycompany.posttest1.db;

import java.sql.*;

public class DbViewer {

    private static final String URL  = "jdbc:mysql://127.0.0.1:3306/lelangdb?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "";

    static {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); } catch (ClassNotFoundException ignored) {}
    }

    public static void showBarang() {
        String sql = """
            SELECT id, nama, kategori, asal, tahun, material, kondisi, sumber,
                   hargaPerolehan AS harga_perolehan
            FROM barang
            ORDER BY id
        """;

        try (Connection cn = DriverManager.getConnection(URL, USER, PASS);
             Statement st  = cn.createStatement();
             ResultSet rs  = st.executeQuery(sql)) {

            printLine();
            System.out.println("| ID | Nama                 | Kategori     | Asal         | Tahun | Material     | Kondisi   | Sumber    | Harga            |");
            printLine();

            boolean ada = false;
            while (rs.next()) {
                ada = true;
                System.out.printf(
                    "| %-2d | %-20s | %-12s | %-12s | %-5d | %-12s | %-9s | %-9s | Rp. %-12.0f |%n",
                    rs.getInt("id"),
                    cut(rs.getString("nama"), 20),
                    cut(rs.getString("kategori"), 12),
                    cut(rs.getString("asal"), 12),
                    rs.getInt("tahun"),
                    cut(rs.getString("material"), 12),
                    cut(rs.getString("kondisi"), 9),
                    cut(rs.getString("sumber"), 9),
                    rs.getDouble("harga_perolehan")
                );
            }

            if (!ada) {
                System.out.printf("| %-110s |%n", "Belum ada data barang");
            }

            printLine();

        } catch (SQLException e) {
            System.out.println("Error JDBC/Statement: " + e.getMessage());
        }
    }

    private static String cut(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return (max <= 1) ? s.substring(0, 1) : s.substring(0, max - 1) + "…";
    }

    private static void printLine() {
        System.out.println("+----+----------------------+--------------+--------------+-------+--------------+-----------+-----------+------------------+");
    }
}
