package com.mycompany.posttest1.main;

import com.mycompany.posttest1.service.Service;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Service service = new Service(in);

        outer: while (true) { 
            tampilkanMenu();
            System.out.print("Pilih menu [1-6] : ");
            String pilih = in.nextLine().trim();

            switch (pilih) {
                case "1" -> service.tambahBarang();        // CREATE (ORM)
                case "2" -> service.tampilkanDenganJDBC(); // READ tampilan: JDBC Statement (SATU-SATUNYA)
                case "3" -> service.perbaruiBarang();      // UPDATE (ORM)
                case "4" -> service.hapusBarang();         // DELETE (ORM)
                case "5" -> service.cariBarang();          // SEARCH (ORM)
                case "6" -> {
                    System.out.print("Apakah yakin kamu ingin keluar? (y/n) : ");
                    if (in.nextLine().trim().equalsIgnoreCase("y")) {
                        System.out.println("\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                        System.out.println("  Terima kasih Telah Menggunakan Program AntikAesthetic!! ");
                        System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                        break outer; // <— keluar dari while
                    } else {
                        System.out.println("\n<<<<< Kembali ke menu utama AntikAesthetic >>>>>");
                    }
                }
                default -> System.out.println("Pilihan tidak valid.");
            }

            service.enterUntukLanjut();
        }

        in.close(); // sekarang tidak unreachable
    }

    private static void tampilkanMenu() {
        System.out.println("\n==================================================================");
        System.out.println("||          ^^ SELAMAT DATANG DI AntikAesthetic ^^               ||");
        System.out.println("==================================================================");
        System.out.println("--------------------------- MENU UTAMA ----------------------------");
        System.out.println("||  1. Tambah Barang                                             ||");
        System.out.println("||  2. Tampilkan Semua Barang                                    ||");
        System.out.println("||  3. Perbarui Barang                                           ||");
        System.out.println("||  4. Hapus Barang (berdasarkan id)                             ||");
        System.out.println("||  5. Cari Barang (nama/kategori/asal)                          ||");
        System.out.println("||  6. Keluar                                                    ||");
        System.out.println("==================================================================");
    }
}
